from controller import Robot, Keyboard

# Constants
TIME_STEP = 32
MAX_VELOCITY = 10.0
ANGLE_STEP = 40 * 3.14159 / 180  # 40 degrees in radians
POSITION_FIRE = ANGLE_STEP       # +40°
POSITION_READY = 0.0             # 0°

# Initialize robot and keyboard
robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

# Get motor & sensor
try:
    motor = robot.getDevice('motor1')
    sensor = robot.getDevice('motor1_sensor')
    sensor.enable(timestep)
    mechanism_enabled = True
except Exception:
    mechanism_enabled = False

# Get wheels
try:
    wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
    for wheel in wheels:
        wheel.setPosition(float('inf'))
        wheel.setVelocity(0)
    platform_enabled = True
except Exception:
    platform_enabled = False

# State: alternate between "ready" and "fire"
current_state = "ready"  # 開始時允許發射（因為假設球已經到位）

# Key debounce
key_debounce = {
    'f': False,
    'c': False
}

print("控制說明：")
print("↑ ↓ ← →：控制平台移動")
print("C：給球（機構回到起始位置）")
print("F：發射球（機構旋轉 +40°）")
print("Q：離開模擬器")

while robot.step(timestep) != -1:
    key = keyboard.getKey()

    # Platform movement
    if platform_enabled:
        if key == Keyboard.UP:
            for wheel in wheels:
                wheel.setVelocity(MAX_VELOCITY)
        elif key == Keyboard.DOWN:
            for wheel in wheels:
                wheel.setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.LEFT:
            wheels[0].setVelocity(MAX_VELOCITY)
            wheels[1].setVelocity(-MAX_VELOCITY)
            wheels[2].setVelocity(MAX_VELOCITY)
            wheels[3].setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.RIGHT:
            wheels[0].setVelocity(-MAX_VELOCITY)
            wheels[1].setVelocity(MAX_VELOCITY)
            wheels[2].setVelocity(-MAX_VELOCITY)
            wheels[3].setVelocity(MAX_VELOCITY)
        elif key == ord('Q') or key == ord('q'):
            print("Exiting...")
            break
        else:
            for wheel in wheels:
                wheel.setVelocity(0)

    # Mechanism control
    if mechanism_enabled:
        # F - 發射球
        if key == ord('F') or key == ord('f'):
            if not key_debounce['f'] and current_state == "ready":
                motor.setPosition(POSITION_FIRE)
                current_state = "wait_for_c"
                print("已發射球，請按 C 給下一顆球")
            key_debounce['f'] = True
        else:
            key_debounce['f'] = False

        # C - 給球
        if key == ord('C') or key == ord('c'):
            if not key_debounce['c'] and current_state == "wait_for_c":
                motor.setPosition(POSITION_READY)
                current_state = "ready"
                print("已準備下一顆球，可以再次發射")
            key_debounce['c'] = True
        else:
            key_debounce['c'] = False
