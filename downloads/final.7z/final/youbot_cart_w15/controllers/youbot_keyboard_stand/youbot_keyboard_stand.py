from controller import Robot, Keyboard

# Constants
WHEEL_RADIUS = 0.1
L = 0.471
W = 0.376
MAX_VELOCITY = 10.0
SCORE_THRESHOLD = 200
COOLDOWN = 1.0

# Initialize robot and timestep
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Devices
sensor = robot.getDevice('sensor')
sensor.enable(timestep)

keyboard = Keyboard()
keyboard.enable(timestep)

# Motors
wheels = [
    robot.getDevice("wheel5"),  # Front-right
    robot.getDevice("wheel6"),  # Front-left
    robot.getDevice("wheel7"),  # Rear-right
    robot.getDevice("wheel8")   # Rear-left
]
for wheel in wheels:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

def set_wheel_velocity(v1, v2, v3, v4):
    wheels[0].setVelocity(v1)
    wheels[1].setVelocity(v2)
    wheels[2].setVelocity(v3)
    wheels[3].setVelocity(v4)

# Game loop
score = 0
last_score_time = 0

print("Control keys: W = forward, S = backward, A = turn left, D = turn right, Q = quit")

while robot.step(timestep) != -1:
    sensor_value = sensor.getValue()
    current_time = robot.getTime()

    # Check for scoring
    if sensor_value > SCORE_THRESHOLD and (current_time - last_score_time) > COOLDOWN:
        score += 2
        last_score_time = current_time
        print(f"得分！目前得分：{score}")

    key = keyboard.getKey()
    velocity = MAX_VELOCITY

    if key == ord('W') or key == ord('w'):
        # Move forward
        set_wheel_velocity(velocity, velocity, velocity, velocity)
    elif key == ord('S') or key == ord('s'):
        # Move backward
        set_wheel_velocity(-velocity, -velocity, -velocity, -velocity)
    elif key == ord('A') or key == ord('a'):
        # Turn left
        set_wheel_velocity(-velocity, velocity, -velocity, velocity)
    elif key == ord('D') or key == ord('d'):
        # Turn right
        set_wheel_velocity(velocity, -velocity, velocity, -velocity)
    elif key == ord('Q') or key == ord('q'):
        print("Exiting simulation.")
        break
    else:
        # No key or unsupported key: stop
        set_wheel_velocity(0, 0, 0, 0)
